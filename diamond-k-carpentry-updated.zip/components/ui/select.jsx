export const Select = ({ children }) => <div>{children}</div>;
export const SelectTrigger = ({ children }) => <div className='border px-3 py-2 rounded mb-2'>{children}</div>;
export const SelectValue = ({ placeholder }) => <span>{placeholder}</span>;
export const SelectContent = ({ children }) => <div className='border p-2 rounded bg-white'>{children}</div>;
export const SelectItem = ({ value, children }) => <div className='hover:bg-gray-100 p-1 cursor-pointer' data-value={value}>{children}</div>;