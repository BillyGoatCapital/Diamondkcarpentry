import React from "react";
import { Button } from "./components/ui/button";
import { Card, CardContent } from "./components/ui/card";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import {
  Select,
  SelectItem,
  SelectContent,
  SelectTrigger,
  SelectValue
} from "./components/ui/select";

const products = [
  { name: "Epoxy Tables", photo: "9037417D-CB84-414B-BB35-308DBECF9A26.jpeg", options: ["Option A", "Option B"] },
  { name: "Dining Room Table", photo: "C6097658-8740-4AE7-B3A6-F450524AF500.jpeg", options: ["Option A", "Option B"] },
  { name: "TV Stand Dog Kennel with Epoxy Top", photo: "0344A593-6557-41A4-9E87-DA67CC9BBE9D.jpeg", options: ["Option A", "Option B"] },
  { name: "End Table", photo: "6557CC0F-9901-4756-BECA-B2FDD1BB7679.jpeg", options: ["Option A", "Option B"] },
  { name: "Custom", photo: "4854EAD3-1849-4076-ABD2-B636DA35166C.jpeg", options: ["Option A", "Option B"] },
  { name: "Dog Kennels", photo: "4E939BE7-3D8F-418B-A2E5-AAC499E69559.jpeg", options: ["Option A", "Option B"] },
  { name: "TV Stand (72"W x 40"H x 30"D)", photo: "1C9A0D97-64F9-4FEC-A97B-D8BC368AB8BF.jpeg", options: ["Option A", "Option B"] },
  { name: "Phone Cases", photo: "C5BE5C29-45ED-485A-8F69-18828DD3E13B.jpeg", options: ["Option A", "Option B"] },
  { name: "Custom Furniture/Items", photo: "CB359B10-8858-4323-BF89-21FE808385E2.jpeg", options: ["Option A", "Option B"] },
  { name: "Cutting Boards", photo: "BDA54D02-BA83-4FD8-A89B-E327FB047E84.jpeg", options: ["Option A", "Option B"] },
  { name: "Traveler Cup", photo: "EEF0622FAB5C64695E043DB0.jpeg", options: ["Option A", "Option B"] },
  { name: "Phone Cases", photo: "C7DA9E31-E295-4B63-A614-A9A736FB52F2.jpeg", options: ["Option A", "Option B"] },
  { name: "Custom Sign Making", photo: "22AF5C11-AC25-4841-85E6-6F00B32E3490.jpeg", options: ["Option A", "Option B"] },
  { name: "Coasters", photo: "958EFD6B-AA1F-4DDF-A640-9E848E5C42A1.jpeg", options: ["Option A", "Option B"] },
  { name: "Razors", photo: "3A86B994-8F7F-4E9F-94BC-CC0368B17751.jpeg", options: ["Option A", "Option B"] },
  { name: "Pens", photo: "609D9B0C-2EC6-4359-95EF-4F15B184D9FE.jpeg", options: ["Option A", "Option B"] },
  { name: "Photo V-Carve", photo: "B62031E1-FE37-4BB9-B864-E77363469834.jpeg", options: ["Option A", "Option B"] },
  { name: "Jewelry Boxes / Catchall Trays", photo: "0C94FC1B-2F35-4732-978A-1E72C0C11753.jpeg", options: ["Option A", "Option B"] },
  { name: "Duck Calls", photo: "732316A3-28CE-437E-8585-47EB23CD1A1C.jpeg", options: ["Option A", "Option B"] },
  { name: "Opal Rings", photo: "B223AD35-B56F-4937-9150-B84B897F032A.jpeg", options: ["Option A", "Option B"] }
];

export default function App() {
  return (
    <div className="p-4 bg-gray-100 min-h-screen">
      <h1 className="text-4xl font-bold text-center mb-2">Diamond K Carpentry</h1>
      <p className="text-center text-lg italic mb-6">Handcrafted with Heart, Built to Last</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <img src={product.photo} alt={product.name} className="w-full h-48 object-cover mb-2 rounded" />
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select an option" />
                </SelectTrigger>
                <SelectContent>
                  {product.options.map((option, idx) => (
                    <SelectItem key={idx} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="mt-10 bg-white p-6 rounded shadow">
        <h2 className="text-2xl font-bold mb-4">Custom Order Request</h2>
        <Input placeholder="Your Name" className="mb-4" />
        <Input placeholder="Your Email" className="mb-4" />
        <Textarea placeholder="Describe what you're looking for..." className="mb-4" />
        <Button>Submit Request</Button>
      </div>
    </div>
  );
}